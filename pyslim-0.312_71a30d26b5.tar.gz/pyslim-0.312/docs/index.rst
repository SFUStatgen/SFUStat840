.. pyslim documentation master file, created by
   sphinx-quickstart on Mon May 13 21:12:33 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyslim's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   development
   tutorial
   metadata
   python_api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
